# CS 499 Milestone Four - Database Enhancement

Artifact: Student Grade Tracker

- student_grade_tracker_original.py: original in-memory version
- student_grade_tracker_database.py: enhanced SQLite version

Enhancements:
- Relational Students, Courses, and Grades tables
- Primary and foreign keys
- CRUD-style database operations
- Input validation
- Parameterized SQL queries
- Data integrity constraints
- JOIN and AVG queries

Run:
python student_grade_tracker_database.py
