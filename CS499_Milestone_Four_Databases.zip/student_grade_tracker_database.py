import sqlite3

DB_NAME = "student_grades.db"

def connect_db():
    return sqlite3.connect(DB_NAME)

def create_tables():
    with connect_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS students (
                student_id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS courses (
                course_id INTEGER PRIMARY KEY AUTOINCREMENT,
                course_name TEXT NOT NULL UNIQUE
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS grades (
                grade_id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER NOT NULL,
                course_id INTEGER NOT NULL,
                grade REAL NOT NULL CHECK(grade >= 0 AND grade <= 100),
                FOREIGN KEY (student_id) REFERENCES students(student_id),
                FOREIGN KEY (course_id) REFERENCES courses(course_id),
                UNIQUE(student_id, course_id)
            )
        """)

def validate_grade(grade):
    try:
        value = float(grade)
    except (TypeError, ValueError):
        raise ValueError("Grade must be a number.")
    if value < 0 or value > 100:
        raise ValueError("Grade must be between 0 and 100.")
    return value

def add_student(name):
    if not name or not name.strip():
        raise ValueError("Student name cannot be empty.")
    with connect_db() as conn:
        cursor = conn.execute(
            "INSERT INTO students (name) VALUES (?)", (name.strip(),)
        )
        return cursor.lastrowid

def add_course(course_name):
    if not course_name or not course_name.strip():
        raise ValueError("Course name cannot be empty.")
    with connect_db() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO courses (course_name) VALUES (?)",
            (course_name.strip(),)
        )
        row = conn.execute(
            "SELECT course_id FROM courses WHERE course_name = ?",
            (course_name.strip(),)
        ).fetchone()
        return row[0]

def add_grade(student_id, course_id, grade):
    grade = validate_grade(grade)
    with connect_db() as conn:
        conn.execute(
            """INSERT OR REPLACE INTO grades
               (student_id, course_id, grade) VALUES (?, ?, ?)""",
            (student_id, course_id, grade)
        )

def update_student(student_id, new_name):
    if not new_name or not new_name.strip():
        raise ValueError("Student name cannot be empty.")
    with connect_db() as conn:
        conn.execute(
            "UPDATE students SET name = ? WHERE student_id = ?",
            (new_name.strip(), student_id)
        )

def delete_student(student_id):
    with connect_db() as conn:
        conn.execute("DELETE FROM grades WHERE student_id = ?", (student_id,))
        conn.execute("DELETE FROM students WHERE student_id = ?", (student_id,))

def get_students_with_averages():
    with connect_db() as conn:
        return conn.execute(
            """SELECT s.student_id, s.name, ROUND(AVG(g.grade), 2) AS average
               FROM students s
               LEFT JOIN grades g ON s.student_id = g.student_id
               GROUP BY s.student_id, s.name
               ORDER BY s.name"""
        ).fetchall()

def get_student_grades(student_id):
    with connect_db() as conn:
        return conn.execute(
            """SELECT c.course_name, g.grade
               FROM grades g
               JOIN courses c ON g.course_id = c.course_id
               WHERE g.student_id = ?
               ORDER BY c.course_name""",
            (student_id,)
        ).fetchall()

def main():
    create_tables()
    alice = add_student("Alice Johnson")
    brian = add_student("Brian Smith")
    math = add_course("Mathematics")
    programming = add_course("Programming")
    add_grade(alice, math, 90)
    add_grade(alice, programming, 88)
    add_grade(brian, math, 82)
    add_grade(brian, programming, 80)

    print("Students and averages:")
    for student in get_students_with_averages():
        print(student)

    print("\nAlice's grades:")
    print(get_student_grades(alice))

if __name__ == "__main__":
    main()
