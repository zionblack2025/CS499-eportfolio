students = []

def add_student(name, grades):
    average = sum(grades) / len(grades)
    students.append({"name": name, "grades": grades, "average": average})

def display_students():
    for student in students:
        print(student["name"], student["grades"], student["average"])

add_student("Alice Johnson", [85, 90, 88])
add_student("Brian Smith", [78, 82, 80])
display_students()
