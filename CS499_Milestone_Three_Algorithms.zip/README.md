# CS 499 Milestone Three - Algorithms and Data Structures

Artifact: Student Grade Tracker

Enhancements:
- Dictionary-based student records
- Sorting by name and average
- Binary search for student records
- Class statistics
- Input validation

Run:
python student_grade_tracker_algorithms.py
