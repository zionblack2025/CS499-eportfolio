students = []

def add_student(name, grades):
    if not name.strip() or not grades or any(g < 0 or g > 100 for g in grades):
        raise ValueError("Valid name and grades from 0 to 100 are required.")
    students.append({
        "name": name.strip(),
        "grades": grades,
        "average": sum(grades) / len(grades)
    })

def sort_by_name():
    students.sort(key=lambda s: s["name"].lower())

def sort_by_average():
    students.sort(key=lambda s: s["average"], reverse=True)

def binary_search(name):
    sort_by_name()
    low, high = 0, len(students) - 1
    target = name.strip().lower()
    while low <= high:
        mid = (low + high) // 2
        current = students[mid]["name"].lower()
        if current == target:
            return students[mid]
        if current < target:
            low = mid + 1
        else:
            high = mid - 1
    return None

def class_statistics():
    if not students:
        return None
    averages = [s["average"] for s in students]
    return {
        "highest": max(averages),
        "lowest": min(averages),
        "class_average": sum(averages) / len(averages)
    }

if __name__ == "__main__":
    add_student("Alice", [85, 90, 88])
    add_student("Brian", [72, 80, 75])
    add_student("Carol", [95, 92, 97])
    sort_by_average()
    print("Sorted:", [(s["name"], round(s["average"], 2)) for s in students])
    print("Search:", binary_search("Brian"))
    print("Statistics:", class_statistics())
