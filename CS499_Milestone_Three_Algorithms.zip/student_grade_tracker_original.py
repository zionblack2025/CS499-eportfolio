students = []

def add_student(name, grades):
    students.append({"name": name, "grades": grades})

def calculate_average(grades):
    return sum(grades) / len(grades)

def search_student(name):
    for student in students:
        if student["name"].lower() == name.lower():
            return student
    return None

if __name__ == "__main__":
    add_student("Alice", [85, 90, 88])
    add_student("Brian", [72, 80, 75])
    for student in students:
        print(student["name"], calculate_average(student["grades"]))
