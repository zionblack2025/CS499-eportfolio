# Student Grade Tracker - Milestone Two

Software Design and Engineering enhancement for CS 499.

## Enhancements
- Modular functions
- Input validation
- Error handling
- SQLite data storage
- Parameterized SQL queries
- Student searching
- Grade average calculation
- Basic automated tests

## Run
python student_grade_tracker.py

## Test
python -m unittest test_student_grade_tracker.py
