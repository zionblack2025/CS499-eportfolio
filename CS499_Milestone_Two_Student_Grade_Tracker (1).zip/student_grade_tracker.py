import sqlite3

DB_NAME = "students.db"


def connect_db():
    return sqlite3.connect(DB_NAME)


def create_tables():
    with connect_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                course TEXT NOT NULL,
                grade REAL NOT NULL CHECK(grade >= 0 AND grade <= 100)
            )
        """)


def validate_grade(grade):
    try:
        value = float(grade)
        if 0 <= value <= 100:
            return value
    except ValueError:
        pass
    return None


def add_student(name, course, grade):
    if not name.strip() or not course.strip():
        raise ValueError("Name and course are required.")

    valid_grade = validate_grade(str(grade))
    if valid_grade is None:
        raise ValueError("Grade must be between 0 and 100.")

    with connect_db() as conn:
        conn.execute(
            "INSERT INTO students (name, course, grade) VALUES (?, ?, ?)",
            (name.strip(), course.strip(), valid_grade)
        )


def search_student(name):
    with connect_db() as conn:
        return conn.execute(
            "SELECT id, name, course, grade FROM students "
            "WHERE name LIKE ? ORDER BY name",
            (f"%{name.strip()}%",)
        ).fetchall()


def calculate_average(name):
    with connect_db() as conn:
        row = conn.execute(
            "SELECT AVG(grade) FROM students WHERE name = ?",
            (name.strip(),)
        ).fetchone()

    return row[0] if row and row[0] is not None else None


def main():
    create_tables()

    while True:
        print("\nStudent Grade Tracker")
        print("1. Add student grade")
        print("2. Search student")
        print("3. View average")
        print("4. Exit")

        choice = input("Choose an option: ").strip()

        try:
            if choice == "1":
                name = input("Student name: ")
                course = input("Course: ")
                grade = input("Grade (0-100): ")
                add_student(name, course, grade)
                print("Record added successfully.")

            elif choice == "2":
                name = input("Student name: ")
                records = search_student(name)
                if records:
                    for record in records:
                        print(record)
                else:
                    print("Student not found.")

            elif choice == "3":
                name = input("Student name: ")
                average = calculate_average(name)
                if average is None:
                    print("No grades found.")
                else:
                    print(f"Average: {average:.2f}")

            elif choice == "4":
                print("Goodbye.")
                break

            else:
                print("Invalid option. Please choose 1-4.")

        except ValueError as error:
            print(f"Error: {error}")


if __name__ == "__main__":
    main()
