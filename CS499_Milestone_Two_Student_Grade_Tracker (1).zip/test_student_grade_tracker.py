import unittest
from student_grade_tracker import validate_grade


class TestGradeValidation(unittest.TestCase):

    def test_valid_grade(self):
        self.assertEqual(validate_grade("85"), 85.0)

    def test_grade_above_100(self):
        self.assertIsNone(validate_grade("105"))

    def test_negative_grade(self):
        self.assertIsNone(validate_grade("-5"))

    def test_invalid_text(self):
        self.assertIsNone(validate_grade("abc"))


if __name__ == "__main__":
    unittest.main()
